package com.dragonnest.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 21, 43));
        getWindow().setNavigationBarColor(Color.rgb(7, 21, 43));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new LauncherBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class LauncherBridge {
        @JavascriptInterface
        public void showAppPicker(String key) {
            runOnUiThread(() -> showInstalledApps(key));
        }

        @JavascriptInterface
        public void launchApp(String packageName) {
            runOnUiThread(() -> {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
                    if (launch != null) startActivity(launch);
                    else Toast.makeText(MainActivity.this, "Aplikasi tidak ditemukan atau tidak dapat dibuka.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuka aplikasi.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void showInstalledApps(String key) {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> results = pm.queryIntentActivities(query, 0);
        List<ResolveInfo> apps = new ArrayList<>();
        for (ResolveInfo info : results) {
            if (info.activityInfo != null && !getPackageName().equals(info.activityInfo.packageName)) apps.add(info);
        }
        Collections.sort(apps, Comparator.comparing(info -> info.loadLabel(pm).toString().toLowerCase()));
        if (apps.isEmpty()) {
            Toast.makeText(this, "Tidak ada aplikasi yang bisa dipilih.", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[apps.size()];
        for (int i = 0; i < apps.size(); i++) names[i] = apps.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle("Pilih aplikasi")
            .setItems(names, (dialog, which) -> {
                ResolveInfo selected = apps.get(which);
                String pkg = selected.activityInfo.packageName;
                String label = selected.loadLabel(pm).toString();
                String js = "onNativeAppSelected(" + org.json.JSONObject.quote(key) + ","
                    + org.json.JSONObject.quote(pkg) + "," + org.json.JSONObject.quote(label) + ")";
                webView.evaluateJavascript(js, null);
            }).setNegativeButton("Batal", null).show();
    }
}
