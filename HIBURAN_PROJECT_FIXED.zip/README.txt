HIBURAN - ANDROID PROJECT (Dragon Nest Launcher)

Build APK via GitHub:
1. Extract ZIP.
2. Create a new GitHub repository.
3. Upload all files and folders from this project (including .github).
4. Open repository > Actions.
5. Select "Build Dragon Nest Launcher APK" > Run workflow.
6. After completion, open the workflow run and download artifact:
   Dragon-Nest-Launcher-APK
7. Extract the downloaded artifact ZIP and install app-debug.apk on Android.

Features:
- Uses the supplied Dragon Nest wallpaper as-is.
- Uses a contain/crop-safe full-screen wallpaper layout (object-fit: cover).
- Native Android installed-app picker in settings.
- Tapping wallpaper app hotspots launches the selected installed app.
- Selected apps are saved in browser storage inside the app.

Note:
QUERY_ALL_PACKAGES is included because this app's core function is to act as an app launcher and provide a picker of installed launchable apps. Google Play distribution has additional policy requirements; for personal testing/sideloading this project can be built through GitHub Actions.


IMPORTANT LAUNCHER BEHAVIOR
The wallpaper buttons call the Android Java bridge (Android.launchApp). Android launches the selected installed app as a separate app/activity, outside the HIBURAN WebView. The native app picker lists installed launchable apps.
